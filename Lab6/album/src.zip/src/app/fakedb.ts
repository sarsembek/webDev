import {Album} from "./models";

export const ALBUMS: Album[] = [
  {
    userId: 1,
    id: 1,
    title: "quidem molestiae enim"
  },
  {
    userId: 1,
    id: 2,
    title: "2quidem molestiae enim"
  }
]